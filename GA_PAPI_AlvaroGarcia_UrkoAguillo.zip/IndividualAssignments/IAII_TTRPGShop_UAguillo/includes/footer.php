<hr>
<footer>
    <p>TTRPG Shop © 2025</p>
</footer>
</body>
</html>