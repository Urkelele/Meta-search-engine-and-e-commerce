<style>
#footer {
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 50px;
    background: #373d37;
    color: white;
    text-align: center;
}
</style>
<br><br><br>
<div id="footer"><br>Tech Shop</div>
