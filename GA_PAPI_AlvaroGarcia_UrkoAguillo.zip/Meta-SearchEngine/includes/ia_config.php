<?php
return [
    "ttrpg" => [
        "base_url" => "http://localhost/Meta-search-engine-and-e-commerce/IndividualAssignments/IAII_TTRPGShop_UAguillo/api/",
        "api_key"  => "ttrpg-secret-123"
    ],
    "techShop" => [
        "base_url" => "http://localhost/Meta-search-engine-and-e-commerce/IndividualAssignments/IAII_TechShop_AGarcia/api/",
        "api_key"  => "TECHSHOP_SECRET_123"
    ],
];