<?php
return [
    'db_host' => 'localhost',
    'db_name' => 'tech_shop',
    'db_user' => 'root',
    'db_pass' => '',
    'base_url' => 'http://localhost/IA2_PAPI/public',
    'password_min_length' => 6,
];
