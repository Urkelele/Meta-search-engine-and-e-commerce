<?php
http_response_code(404);
?>

<h1>404 - Page not found</h1>

<p>The page you are trying to access does not exist.</p>

<p>
  <a href="index.php?page=home">Go back to home</a>
</p>
